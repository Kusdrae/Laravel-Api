<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Covid;
class CovidController extends Controller
{
        public function index()
    {
        return Covid::all();
    }

	    public function create()
    {
        //
    }

        public function store(Request $request)
    {
	   print_r($request->all());
        return Covid::create($request->all()); 
    }

        public function show($id)
    {
        return Covid::findOrFail($id);
    }

        public function edit($id)
    {
        //
    }

        public function update(Request $request, $id)
    {
        $covid = Covid::findOrFail($id);
	   $covid->update($request->all());
    }

        public function destroy($id)
    {
        $covid = Covid::findOrFail($id);
	   $covid->delete(); 
    }
}
